"""Hessian-Adaptive Sparse Vector Quantizer (HAS-VQ)."""
