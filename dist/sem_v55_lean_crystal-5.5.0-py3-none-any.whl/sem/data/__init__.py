"""Data pipeline for SEM V5.5 training."""
