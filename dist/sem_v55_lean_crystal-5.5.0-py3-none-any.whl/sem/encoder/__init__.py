"""MESH-SDR Entropic Encoder module."""
