"""Born Collapse Sampler module."""
