"""Cayley-Soliton Propagator module."""
