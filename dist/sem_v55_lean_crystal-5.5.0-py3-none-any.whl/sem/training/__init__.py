"""Training infrastructure for SEM V5.5."""
